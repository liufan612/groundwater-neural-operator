BEGIN options
END options

BEGIN griddata
  diffc
    CONSTANT       0.00000000
  alh
    CONSTANT      40.00000000
  ath1
    CONSTANT       4.00000000
  atv
    CONSTANT       0.10000000
END griddata

